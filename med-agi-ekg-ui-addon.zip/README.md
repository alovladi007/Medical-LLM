# EKG UI Add-on

This drop adds a Next.js page at `/ekg` that talks to your EKG API.

## Setup
- Copy `ui/app/ekg/page.tsx` into your UI project.
- Set `NEXT_PUBLIC_EKG_API` in your `.env.local` (default: `http://127.0.0.1:8016`).

## Use
- Navigate to `/ekg`.
- Generate a demo waveform or paste exactly 1000 samples.
- Click **Run inference** to see per-label probabilities and an uncertainty badge.
- The header shows a Triton health badge when the EKG API exposes `/v1/ekg/health`.
