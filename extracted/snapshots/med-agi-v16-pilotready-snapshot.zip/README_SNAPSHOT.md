# v16 Pilot-Ready Snapshot
This is the final pilot-ready version (v16) packaged as a runnable repo layout.

Includes smoke tests, runbook, publish scripts, CI workflow, and pilot checklist.
