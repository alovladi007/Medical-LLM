# v9 Triton snapshot

`docker compose up --build` then GET http://localhost:8006/v1/triton/health
