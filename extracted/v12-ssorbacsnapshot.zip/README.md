# v12 SSO/RBAC snapshot

Set OIDC_ISSUER/AUDIENCE/JWKS_URL and OPA_URL, then run.
