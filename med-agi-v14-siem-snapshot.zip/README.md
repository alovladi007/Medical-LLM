# v14 SIEM snapshot

`docker compose up --build` then POST to /v1/ops/siem/log
