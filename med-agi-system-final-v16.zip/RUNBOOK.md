# RUNBOOK — Pilot Deployment

## Deploy
docker compose --profile dev up --build  # or prod
Set env vars for OIDC, OPA, SIEM, Imaging.
