# Med‑AGI Pilot Starter Kit

This repository packages everything needed to kick off a **shadow‑mode clinical pilot**.

## Contents
- **v16/** — Final pilot‑ready bundle (smoke tests, runbook, CI workflow, model‑card publisher).
- **go_nogo/** — Pilot Go/No‑Go Readiness Sweep (bootstrap, load tests, chaos, alerts, retention notes).
- **snapshots/** — Four runnable milestones:
  - med-agi-v9-triton-snapshot.zip
  - med-agi-v12-ssorbacsnapshot.zip
  - med-agi-v14-siem-snapshot.zip
  - med-agi-v16-pilotready-snapshot.zip

## Quick start
1) Review `v16/` and `go_nogo/`.
2) Set environment variables for OIDC/OPA/SIEM/DICOM/Triton.
3) Run the pilot bootstrap to validate services:
   ```bash
   cd go_nogo
   python3 bootstrap.py --profile dev      --imaging http://localhost:8006      --eval http://localhost:8005      --anchor http://localhost:8007      --modelcards http://localhost:8008      --ops http://localhost:8010
   ```
4) Run load tests:
   ```bash
   k6 run scripts/k6/cxr.js   -e IMAGING=http://localhost:8006
   k6 run scripts/k6/ekg.js   -e EKG=http://localhost:8016
   k6 run scripts/k6/dicom.js -e IMAGING=http://localhost:8006
   ```
5) Optional chaos check (fallback from Triton to ORT/stub):
   ```bash
   IMAGING=http://localhost:8006 bash scripts/chaos_triton_down.sh
   ```

## Notes
- The **snapshots** are self‑contained zip files—extract and run them independently if you need to examine earlier milestones.
- For the full deployment procedure, see `v16/RUNBOOK.md` and `v16/PILOT_CHECKLIST.md`.
