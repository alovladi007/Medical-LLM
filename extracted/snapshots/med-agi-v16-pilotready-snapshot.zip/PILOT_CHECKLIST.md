# PILOT CHECKLIST
- [ ] OIDC/OPA configured
- [ ] Imaging reachable
- [ ] PHI OCR working
- [ ] Model cards visible
