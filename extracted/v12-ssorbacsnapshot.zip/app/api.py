from fastapi import FastAPI, Header, HTTPException, Depends
from oidc import OIDC
from opa import allow
app = FastAPI()
def auth(authorization: str = Header(None)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing token")
    token = authorization.split(" ",1)[1]
    claims = OIDC().verify(token)
    if not allow({"sub": claims.get("sub"), "role": claims.get("role","clinician")}):
        raise HTTPException(403, "Policy deny")
    return claims
@app.get("/v1/secure")
def secure_route(claims=Depends(auth)):
    return {"ok": True, "user": claims.get("email","unknown")}
